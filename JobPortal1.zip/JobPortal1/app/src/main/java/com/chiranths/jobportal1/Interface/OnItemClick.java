package com.chiranths.jobportal1.Interface;

public interface OnItemClick {
    void onClick1 (int value);
}
