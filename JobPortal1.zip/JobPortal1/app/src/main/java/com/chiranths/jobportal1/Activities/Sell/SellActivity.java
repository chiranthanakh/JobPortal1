package com.chiranths.jobportal1.Activities.Sell;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.chiranths.jobportal1.R;

public class SellActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sell);


    }
}